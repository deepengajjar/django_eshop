# from django.shortcuts import render, redirect


# from .models.product import Product

# from .models.category import Category

# from django.views import View


# # Create your views here.


# # def index(request):
# #     return HttpResponse("<h1>Request Received....</h1>")

# def index(request):
#     prod = None
#     cato = Category.get_all_category()
#     CategoryID = request.GET.get('category')
#     # print(CategoryID)
#     print('You are : ', request.session.get('email'))

#     if CategoryID:
#         prod = Product.get_all_products_by_category_id(CategoryID)
#     else:
#         prod = Product.get_all_products()
#     return render(request, "index.html", {'products': prod, 'categories': cato})


# # class Signup(View):

# #     def get(self, request):
# #         return render(request, 'signup.html')

# #     def post(self, request):
# #         firstname = request.POST.get('firstname')
# #         lastname = request.POST.get('lastname')
# #         contact = request.POST.get('contact')
# #         email = request.POST.get('email')
# #         password = request.POST.get('pass')

# #         customer = Customer(firstname=firstname, lastname=lastname,
# #                             contact=contact, email=email, password=password)

# #         error_message = None

# #         # form values after error message

# #         form_values = {
# #             'firstname': firstname,
# #             'lastname': lastname,
# #             'email': email,
# #             'contact': contact
# #         }

# #         if len(firstname) < 3:
# #             error_message = "First Name or Last Name must be more than 4 charaters"
# #         elif len(lastname) < 3:
# #             error_message = "First Name or Last Name must be more than 4 charaters"
# #         elif len(contact) < 10:
# #             error_message = "Contact Number should be more than 10 digits"
# #         elif len(contact) > 15:
# #             error_message = "Contact Number should be less than 15 digits"
# #         elif customer.isExistsEmail():
# #             error_message = "Email ID Already Exists"
# #         elif customer.isExistsContact():
# #             error_message = "Contact Number Already Exists"

# #         # saving above data in Customer table
# #         if not error_message:

# #             # converting normal password to secure hash password
# #             customer.password = make_password(password)

# #             customer.register()

# #             # homepage is the name of index.html url in urls.py file
# #             return redirect("homepage")

# #         else:

# #             data = {
# #                 'error': error_message,
# #                 'value': form_values
# #             }
# #             return render(request, "signup.html", data)


# # def signup(request):
# #     print(request.method)
# #     print(request.POST)

# #     if request.method == "GET":
# #         return render(request, 'signup.html')
# #     else:
# #         firstname = request.POST.get('firstname')
# #         lastname = request.POST.get('lastname')
# #         contact = request.POST.get('contact')
# #         email = request.POST.get('email')
# #         password = request.POST.get('pass')

# #         customer = Customer(firstname=firstname, lastname=lastname,
# #                             contact=contact, email=email, password=password)

# #         error_message = None

# #         # form values after error message

# #         form_values = {
# #             'firstname': firstname,
# #             'lastname': lastname,
# #             'email': email,
# #             'contact': contact
# #         }

# #         if len(firstname) < 3:
# #             error_message = "First Name or Last Name must be more than 4 charaters"
# #         elif len(lastname) < 3:
# #             error_message = "First Name or Last Name must be more than 4 charaters"
# #         elif len(contact) < 10:
# #             error_message = "Contact Number should be more than 10 digits"
# #         elif len(contact) > 15:
# #             error_message = "Contact Number should be less than 15 digits"
# #         elif customer.isExistsEmail():
# #             error_message = "Email ID Already Exists"
# #         elif customer.isExistsContact():
# #             error_message = "Contact Number Already Exists"

# #         # saving above data in Customer table
# #         if not error_message:

# #             # converting normal password to secure hash password
# #             customer.password = make_password(password)

# #             customer.register()

# #             # homepage is the name of index.html url in urls.py file
# #             return redirect("homepage")

# #         else:

# #             data = {
# #                 'error': error_message,
# #                 'value': form_values
# #             }
# #             return render(request, "signup.html", data)


# # class Login(View):

# #     def get(self, request):
# #         return render(request, 'login.html')

# #     def post(self, request):
# #         email = request.POST.get('email')
# #         password = request.POST.get('pass')
# #         cust_email = Customer.get_user_by_email(email)

# #         error_message = None

# #         if cust_email:
# #             flag = check_password(password, cust_email.password)
# #             if flag:

# #                 request.session['customer'] = cust_email.id
# #                 request.session['email'] = cust_email.email

# #                 return redirect('homepage')
# #             else:
# #                 error_message = "Invalid Email Or Password"
# #         else:
# #             error_message = "Invalid Email Or Password"

# #         # print(email, password, cust_email)

# #         return render(request, 'login.html', {'error': error_message})


# # def login(request):
# #     if request.method == "GET":
# #         return render(request, 'login.html')
# #     else:
# #         email = request.POST.get('email')
# #         password = request.POST.get('pass')
# #         cust_email = Customer.get_user_by_email(email)

# #         error_message = None

# #         if cust_email:
# #             flag = check_password(password, cust_email.password)
# #             if flag:

# #                 request.session['customer'] = cust_email.id
# #                 request.session['email'] = cust_email.email

# #                 return redirect('homepage')
# #             else:
# #                 error_message = "Invalid Email Or Password"
# #         else:
# #             error_message = "Invalid Email Or Password"

# #         # print(email, password, cust_email)

# #         return render(request, 'login.html', {'error': error_message})
