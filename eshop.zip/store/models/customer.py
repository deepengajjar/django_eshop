from django.db import models


class Customer(models.Model):
    firstname = models.CharField(max_length=100)
    lastname = models.CharField(max_length=100)
    contact = models.CharField(max_length=15)
    email = models.EmailField()
    password = models.CharField(max_length=50000)

    def register(self):
        self.save()

    # To check if user already exists based on email id
    def isExistsEmail(self):
        if Customer.objects.filter(email=self.email):
            return True

        return False

     # To check if user already exists based on Contact Number
    def isExistsContact(self):
        if Customer.objects.filter(contact=self.contact):
            return True

        return False

    @staticmethod
    def get_user_by_email(email):

        try:
            return Customer.objects.get(email=email)
        except:
            False
