from django.shortcuts import render, redirect


from store.models.product import Product

from store.models.category import Category

from django.views import View


# Create your views here.


# def index(request):
#     prod = None
#     cato = Category.get_all_category()
#     CategoryID = request.GET.get('category')
#     # print(CategoryID)
#     print('You are : ', request.session.get('email'))

#     if CategoryID:
#         prod = Product.get_all_products_by_category_id(CategoryID)
#     else:
#         prod = Product.get_all_products()
#     return render(request, "index.html", {'products': prod, 'categories': cato})


class Index(View):

    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        prod = None
        cato = Category.get_all_category()
        CategoryID = request.GET.get('category')
        # print(CategoryID)
        # print('You are : ', request.session.get('email'))

        if CategoryID:
            prod = Product.get_all_products_by_category_id(CategoryID)
        else:
            prod = Product.get_all_products()
        return render(request, "index.html", {'products': prod, 'categories': cato, })

    def post(self, request):

        prod_id = request.POST.get('product')

        remove = request.POST.get('remove')

        cart = request.session.get('cart')

        if cart:

            quantity = cart.get(prod_id)

            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(prod_id)
                    else:
                        cart[prod_id] = quantity-1
                else:
                    cart[prod_id] = 1 + quantity
            else:
                cart[prod_id] = 1

        else:
            cart = {}
            cart[prod_id] = 1

        request.session['cart'] = cart

        return redirect('homepage')
