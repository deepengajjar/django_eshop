from django.shortcuts import render, redirect

from store.models.product import Product

from django.contrib.auth.hashers import check_password


from django.views import View


class Cart(View):

    def get(self, request):

        product_ids = list(request.session.get('cart').keys())
        prod_cart = Product.get_products_by_id(product_ids)
        return render(request, 'cart.html', {'prod_cart': prod_cart})
